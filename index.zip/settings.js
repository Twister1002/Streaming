var settings = {
    "social": {
        "twitter": "Private_Panda_",
        "facebook": "",
        "instagram": "",
        "youtube": ""
    }
}